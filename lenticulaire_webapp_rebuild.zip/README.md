# Générateur d’images lenticulaires

Ce projet HTML permet de générer une image lenticulaire à partir de deux images.

## Fonctionnement
- Sélectionner deux images de même taille.
- Choisir le format, l’unité (px ou mm), et le nombre de bandes.
- Cliquer sur “Générer” puis “Télécharger”.

## Auteur
René Hippert
